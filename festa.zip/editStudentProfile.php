 
          
<div class="col-12 text-center">
<h3 class="mb-4" style="color: white;"> add Guide</h3>
</div>
<form id="Edit_Student_myForm" >
<table>
    <tr>
        <th>Your Name</th>
        <th>Your Id</th>
        
    </tr>
    <tr>
        <td><input type="text" name="sudent_name" style="color: white;" ></td>
        <td><input type="text" name="Student_Id" style="color: white;"></td>
         
    </tr>
    <tr>
        <th>Your phone</th> 
        <th>Your Adress</th>
        <th>Your Password</th>
    </tr>
    <tr>
        <td><input style="color: white;" type="tel" name="Student_phone" pattern="^((\+92)|(0092))-{0,1}\d{3}-{0,1}\d{7}$" placeholder="Enter Pakistani phone number" required ></td>
        <td><input style="color: white;" type="text" name="Student_adress"></td>
        <td><input style="color: white;" type="password" name="Student_Password" placeholder="Enter password" required></td>
    </tr>
    <tr>
        <th>Your email</th>
    </tr>
    <tr>
        <td><input type="text" name="student_email" style="color: white;"></td>
        <td><input type="hidden" name="hiddenField" value="Edit_Student_profile"></td>
    </tr>
    <tr>
        <th>Edit Image</th>
    </tr>
    <tr>
        <td><input type="file" id="image" name="image" accept="image/*" class="file-input"></td>
    </tr>
    <tr>
        <td><button id="Edit_Student_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
    </tr>
</table>
</form>


 