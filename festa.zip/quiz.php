

                  <style>
                        .Quiz_panel{
                           width: 65vw;
                           height: 90vh;
                           
                        }
                        .question_row{
                          width: 65vw;
                          height: 12vh;
                          border: 2px solid #219c02;
                          filter: drop-shadow(2px 2px 4px #219c02); 
                          border-radius: 30px;
                          background-color:  #101E14;
                          text-align: center;
                        }
                        .Answer_row{
                           width: 65vw;
                           height: 20vh;
                           display: flex;
                           background-color:  #101E14;
                           flex-direction: column;
                           margin-top: 7px;
                           margin-bottom: 7px;
                           border-radius: 30px;
                        }
                        .Answer_row input{
                           width: 4vw;
                           height: 2vh;
                        }
                  
                  

                  </style>
                  <div class="Quiz_panel" >
                         <div class="quiz_form" >
                              <div class="col-12 text-center">
                                 <h3 class="mb-4" style="color:white;"> Your Quiz</h3>
                              </div>
                              <form id="quizForm">
                                 <div class="question_row">
                                       <h6 style="color:white; margin-top:20px;">1 : Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</h6>
                                 </div>
                                 <div class="Answer_row">
                                       <label style="color:white"><input type="radio" name="question_1" value="Haji"> Haji</label>
                                       <label style="color:white"><input type="radio" name="question_1" value="ahsan"> ahsan</label>
                                       <label style="color:white"><input type="radio" name="question_1" value="dojacat"> dojacat</label>
                                       <label style="color:white"><input type="radio" name="question_1" value="2pac"> 2pac</label>
                                       <label style="color:white;"><input type="checkbox" name="Correct_answer[]" value="dojacat"> Correct Answer</label>
                                 </div>

                                 <div class="question_row">
                                       <h6 style="color:white; margin-top:20px;">2 : Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</h6>
                                 </div>
                                 <div class="Answer_row">
                                       <label style="color:white"><input type="radio" name="question_2" value="pheeka"> pheeka</label>
                                       <label style="color:white"><input type="radio" name="question_2" value="basharat"> basharat</label>
                                       <label style="color:white"><input type="radio" name="question_2" value="nanshop"> nanshop</label>
                                       <label style="color:white"><input type="radio" name="question_2" value="amirDogar"> amirDogar</label>
                                       <label style="color:white;"><input type="checkbox" name="Correct_answer[]" value="amirDogar"> Correct Answer</label>
                                 </div>
                                 <div class="question_row">
                                       <h6 style="color:white; margin-top:20px;">2 : Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</h6>
                                 </div>
                                 <div class="Answer_row">
                                       <label style="color:white"><input type="radio" name="question_2" value="doodh"> doodh</label>
                                       <label style="color:white"><input type="radio" name="question_2" value="DAhi"> DAhi</label>
                                       <label style="color:white"><input type="radio" name="question_2" value="Lasi"> Lasi</label>
                                       <label style="color:white"><input type="radio" name="question_2" value="dukaan"> dukaan</label>
                                       <label style="color:white;"><input type="hidden"  name="Correct_answer[]" value="Lasi"> Correct Answer</label>
                                 </div>

                                 <!-- Add more questions and options as needed -->

                                 <div class="col-12 text-center">
                                       <button id="submitButton" class="btn custom-btn">Submit</button>
                                 </div>
                              </form>
                         </div>
                  </div>
                  <div id="selectedValues"></div>
                  <div id="correctAnswers"></div>

                  <script>
 

                  </script>