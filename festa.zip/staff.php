        <section class="artists-section section-padding" id="section_3" style="background-image: none; background-color:  #101E14;" >
            <div class="container">
                <div class="row justify-content-center">

                    <div class="col-12 text-center">
                        <h2 class="mb-4" style="color: white; margin-bottom: 20%;">Meet Entrepreneurs</h1>
                    </div>

                    <div class="col-lg-5 col-12">
                        <div class="artists-thumb" style=" border-radius:20px; filter: drop-shadow(2px 2px 4px #219c02); ">
                            <div class="artists-image-wrap">
                                <img src="images/artists/babumushai.jpg"
                                    class="artists-image img-fluid">
                            </div>

                            <div class="artists-hover" style="background-image: none; background-color: #101E14;" >
                                <p>
                                    <strong>Name:</strong>
                                   Usman Tariq
                                </p>

                                <p>
                                    <strong>Qualification:</strong>
                                    MSC - C  S 
                                </p>

                                <p>
                                    <strong>Experties:</strong>
                                    Ai - Ml &amp; Dl
                                </p>

                                <hr>

                                <p class="mb-0">
                                    <strong>Youtube Channel:</strong>
                                    <a href="#">Usman Tariq Official</a>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 col-12">
                        <div class="artists-thumb"  style=" border-radius:20px; filter: drop-shadow(2px 2px 4px #219c02); ">
                            <div class="artists-image-wrap">
                                <img src="images/artists/siranjum.JPEG"
                                    class="artists-image img-fluid">
                            </div>

                            <div class="artists-hover" style="background-image: none; background-color: #101E14;">
                                <p>
                                    <strong>Name:</strong>
                                    Anjum ALi
                                </p>

                                <p>
                                    <strong>Qualification:</strong>
                                    BSCS SE
                                </p>

                                <p>
                                    <strong>Speciality:</strong>
                                    Deep lEarning
                                </p>

                                <hr>

                                <p class="mb-0">
                                    <strong>Youtube Channel:</strong>
                                    <a href="#">Anjum Ali official</a>
                                </p>
                            </div>
                        </div>

                        <div class="artists-thumb"  style=" border-radius:20px; filter: drop-shadow(2px 2px 4px #219c02); ">
                            <img src="images/artists/soundtrap-rAT6FJ6wltE-unsplash.jpg"
                                class="artists-image img-fluid">

                            <div class="artists-hover" style="background-image: none; background-color: #101E14;">
                                <p>
                                    <strong>Name:</strong>
                                    Usman Tariq
                                </p>

                                <p>
                                    <strong>Qualification:</strong>
                                    October 8, 1985
                                </p>

                                <p>
                                    <strong>Speciality:</strong>
                                    Deep LEarning
                                </p>

                                <hr>

                                <p class="mb-0">
                                    <strong>Youtube Channel:</strong>
                                    <a href="#">Bruno Official</a>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>