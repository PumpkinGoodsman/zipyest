<?php
include 'connection.php';

function add_lecture($connect, $table_name ,  $lecture_no , $Lecture_topic , $Description , $outcomes , $video_url , $lesson_pdf  ){
    
    $connection = $connect;
     
    $uploadedFile = $lesson_pdf;

    if (isset($uploadedFile) && $uploadedFile["error"] == 0) {
        $targetDir = "C:\\xampp\\htdocs\\festa\\images\\";// Specify your target directory
        $targetFile = $targetDir . basename($uploadedFile["name"]);
        $documentName = "images/" . $uploadedFile["name"];
        echo $documentName . "<br>";
        $documentFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        $allowedFormats = array("pdf", "doc", "docx");
        
        if (in_array($documentFileType, $allowedFormats)) {
            if (move_uploaded_file($uploadedFile["tmp_name"], $targetFile)) {
                echo "File uploaded successfully.";
            } else {
                echo "Error uploading file.";
            }
        } else {
            echo "Invalid file format. Only PDF, DOC, and DOCX files are allowed.";
        }
    } else {
        echo "No file uploaded or an error occurred during upload.";
    }

    $insert_sql = "INSERT INTO $table_name ( lecture_no, Lecture_topic , Lecture_Description , lecture_outcomes , video_url , lesson_pdf  )
    VALUES (?, ?, ?, ? , ? , ?)";

    $stmt = mysqli_prepare($connection, $insert_sql);
    mysqli_stmt_bind_param($stmt, "isssss",   $lecture_no , $Lecture_topic ,$Description , $outcomes , $video_url ,  $documentName   );

    if (mysqli_stmt_execute($stmt)) {
        // echo "Record inserted successfully!";
    } else {
        // echo "Error inserting record: " . mysqli_stmt_error($stmt);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($connection);
    
}

function edit_lecture($connect, $table_name, $lecture_no, $lecture_topic, $description, $outcomes, $video_url, $lesson_pdf)
{
    $connection = $connect;

    // Check and handle file upload
    $documentName = null;
    $uploadedFile = $lesson_pdf;

    if (isset($uploadedFile) && $uploadedFile["error"] == 0) {
        // Handle file upload logic here (same as before)
        // ...
    }

    // Build the update SQL query based on the provided fields
    $update_sql = "UPDATE $table_name SET ";
    $update_params = [];
    $update_types = "";

    if (isset($lecture_topic)) {
        $update_sql .= "Lecture_topic=?, ";
        $update_params[] = $lecture_topic;
        $update_types .= "s";
    }

    if (isset($description)) {
        $update_sql .= "Lecture_Description=?, ";
        $update_params[] = $description;
        $update_types .= "s";
    }

    if (isset($outcomes)) {
        $update_sql .= "lecture_outcomes=?, ";
        $update_params[] = $outcomes;
        $update_types .= "s";
    }

    if (isset($video_url)) {
        $update_sql .= "video_url=?, ";
        $update_params[] = $video_url;
        $update_types .= "s";
    }

    if (isset($documentName)) {
        $update_sql .= "lesson_pdf=?, ";
        $update_params[] = $documentName;
        $update_types .= "s";
    }

    // Remove the trailing comma and add the WHERE clause
    $update_sql = rtrim($update_sql, ", ") . " WHERE lecture_no=?";
    $update_params[] = $lecture_no;
    $update_types .= "i";

    // Prepare and bind the parameters dynamically
    $stmt = mysqli_prepare($connection, $update_sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, $update_types, ...$update_params);

        if (mysqli_stmt_execute($stmt)) {
            echo "Record updated successfully!";
        } else {
            echo "Error updating record: " . mysqli_stmt_error($stmt);
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($connection);
    }

    mysqli_close($connection);
}

function create_quiz($conn, $courseName, $quizTitle ,  $totalMarks) {
    // Validate input data
    if (strlen($courseName) > 255 || strlen($quizTitle) > 255 || strlen($totalMarks) > 255) {
        echo "Invalid input data.";
        return;
    }

    // Concatenate course name and quiz title to create table name
    $tableName = $courseName . '_' . $quizTitle;

    // SQL query to create the quiz table using prepared statement
    $createQuery = $conn->prepare("CREATE TABLE $tableName (
        indx INT AUTO_INCREMENT PRIMARY KEY,
        Question VARCHAR(255),
        Option_A VARCHAR(255),
        Option_B VARCHAR(255),
        Option_C VARCHAR(255),
        Option_D VARCHAR(255),
        Correct_Answer VARCHAR(255)
    )");

    // Execute the create table query
    if ($createQuery->execute()) {
        echo "Table $tableName created successfully.";
    } else {
        // Log the error to a file
        error_log("Error creating table: " . $createQuery->error, 3, "error.log");
        // User-friendly message
        echo "An error occurred while creating the quiz table. Please try again later.";
        return;
    }

    $createQuery->close();

    $insert_sql = "INSERT INTO quiz_list (course_Name, quiz_title , total_marks  )
    VALUES (?, ?, ?)";

    $stmt = mysqli_prepare( $conn , $insert_sql);
    mysqli_stmt_bind_param($stmt , "sss", $courseName , $quizTitle,  $totalMarks);

    if (mysqli_stmt_execute($stmt)) {
        // echo "Record inserted successfully!";
    } else {
        // echo "Error inserting record: " . mysqli_stmt_error($stmt);
    }
    mysqli_stmt_close($stmt);
    // Close prepared statements
}

function insert_questions_in_quiz($conn, $courseName, $quizTitle, $question, $Option_A, $Option_B, $Option_C, $Option_D, $Correct_answer) {
    // Validate input data
    if (strlen($courseName) > 255 || strlen($quizTitle) > 255) {
        echo "Invalid input data.";
        return;
    }

    // Sanitize table name to prevent SQL injection
    $tableName = mysqli_real_escape_string($conn, $courseName . '_' . $quizTitle);

    // SQL query to create the quiz table using prepared statement
    $insert_sql = "INSERT INTO $tableName (Question, Option_A, Option_B, Option_C, Option_D, Correct_Answer)
    VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($conn, $insert_sql);
    // Specify correct data types for bind_param
    mysqli_stmt_bind_param($stmt, "ssssss", $question, $Option_A, $Option_B, $Option_C, $Option_D, $Correct_answer);

    if (mysqli_stmt_execute($stmt)) {
        // echo "Record inserted successfully!";
    } else {
        // echo "Error inserting record: " . mysqli_stmt_error($stmt);
    }
    mysqli_stmt_close($stmt);
    // Close prepared statements
}


if (isset($_POST['hiddenField'])) {

    $form_to_handle = $_POST['hiddenField'];
    if( $form_to_handle == "add_lecture"){
        add_lecture($connection, $_POST['Course_Name'], $_POST['lecture_no'], $_POST['Lecture_topic'], $_POST['Lecture_Description'], $_POST['lecture_outcomes'], $_POST['video_url'], $_FILES["document"]);
    }
    if( $form_to_handle == "edit_lecture_Form"){
        edit_lecture($connection, $_POST['Course_Name'], $_POST['lecture_no'], $_POST['Lecture_topic'], $_POST['Lecture_Description'], $_POST['lecture_outcomes'], $_POST['video_url'], $_FILES["document"]);
    }
    if( $form_to_handle == "Create_Quiz"){
        create_quiz($connection ,  $_POST['C_Name'] , $_POST['quiz_title']  , $_POST['Total_Marks']);
    }
    if( $form_to_handle == "Add_question_to_quiz"){
        insert_questions_in_quiz($connection, $_POST['course_name'], $_POST['quiz_title'], $_POST['Question'], $_POST['Option_A'], $_POST['Option_B'], $_POST['Option_C'],  $_POST['Option_D'], $_POST['Correct_Answer']);
    }
}    

?>
