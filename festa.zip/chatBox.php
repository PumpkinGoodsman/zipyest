
<style>
    .chat_box{
        width: 40vw;
        height: 70vh;
        margin-left: 19%;
        margin-top: 5%;
        margin-bottom: 5%;
        border-radius: 40px;
        border: 2px solid #269524;
        background-color: #150E19;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    .chat_head{
        width: 39.8vw;
        height: 10vh;
        border-radius: 40px 40px 0px 0px;
        background-color:  #101E14;
        filter: drop-shadow(2px 2px 4px #219c02); 

    }
    .chat_input{
        width: 39.8vw;
        height: 6vh;
        border-radius:  0px  0px 40px 40px;
        background-color:  #101E14;
        filter: drop-shadow(2px 2px 4px #219c02); 
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }
    input{
        border-top: 1px solid #219c02;
        border-bottom: 1px solid #219c02;
        width: 25vw;
        height:6vh;
        filter: drop-shadow(2px 2px 4px #219c02); 
        border-radius: 40px;
    }
    .submit_button{
         width: 3vw;
         height: 6vh;
         border-radius: 30px;
         margin-left: 10px;
         border: 1px solid #219c02;
         background-color:#101E14;
         color: white;
         filter: drop-shadow(1px 1px 2px #219c02); 
    }
    .submit_button:hover {
        background-color: #219c02;
        filter: drop-shadow(0px 0px 0px #219c02); 
    }
    .msg1{
        width: 13vw;
        border-radius: 20px;
        text-align: center;
        background-color:  #101E14;
        filter: drop-shadow(2px 2px 2px #219c02);  
        margin-left: 80px;
        margin-top: 300px;
        border-radius:  0px  20px 20px 20px;
    }
    .msg2{
        width: 13vw;
        text-align: center;
        background-color:  #101E14;
        filter: drop-shadow(2px 2px 2px #219c02);  
        margin-left: 380px;
        display: none;
        border-radius:  20px  0px 20px 20px;
    }
    
    
 
    
</style>


    <div class="chat_box" >
        <div class="chat_head">
            <div class="col-12 text-center">
              <h5 class="mb-4" style="margin-top: 3% ; color: white; ">Python Class Chat Boat</h5>
            </div>
        </div>
        <div class="msg1" >
             <h7 style="color:white;  ">Hello There</h7>
        </div>
        <div class="msg2" >
             <h7 style="color:white;  ">Hello world</h7>
        </div>
        <div class="chat_input">
            <div class="col-12 text-center">
               <div  >
                     <input type="text" placeholder="Write a message"  style="color:white" >
                     <button  class="submit_button" onclick="heellooWorld()"  >➤</button>
               </div>
            </div>
        </div>
        

    </div>

    <script>

function heellooWorld() {
    var element = document.getElementsByClassName("msg2")[0];
    if (element) {
        element.style.display = "block";
    }
}
    </script>