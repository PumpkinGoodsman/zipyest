 
 

     
    <div class="signup_form" id="signUp_form"  style="background-image: none; background-color:  #150E19; border: 0.5px solid #269524; filter: drop-shadow(2px 2px 4px #219c02);">
            <h3 class="text-center mb-4" style="color:white;">Sign Up</h3>
            <table id="form_table" > 
            </table>
            <form class="custom-form ticket-form mb-5 mb-lg-0" id="Sign_up_form"  style="background-image: none; background-color:  #150E19;  " >
                <div class="ticket-form-body"  >
                    <table> 
                        <tr>
                            <td><h6 style="color:white;">student</h6><input type="text" name="name" id="ticket-form-name"   class="form-control" placeholder="Enter Name" required></td>
                            <td><h6 style="color:white;">Student ID</h6><input type="text" name="Student_ID" id="ticket-form-name"   class="form-control" placeholder="Enter Your ID " required></td>
                        </tr>
                        <tr>
                            <td><h6 style="color:white;">student_email</h6><input type="email" name="student_email" id="ticket-form-name"   class="form-control" placeholder="Enter Email" required></td>
                            <td><h6 style="color:white;">student Phone</h6><input type="text" name="student_phone" id="ticket-form-phone" class="form-control" placeholder="Enter Phone Number"  ></td>
                            
                        </tr>
                        <tr>
                            <td><h6 style="color:white;">Password</h6><input type="password" name="password" id="ticket-form-name"   class="form-control" placeholder="set a password" required></td>
                            <td><h6 style="color:white;">confrm Passwod</h6><input type="password" name="confrm_password" id="ticket-form-name"   class="form-control" placeholder="confrm Passwod" required></td>
                        </tr>
                        <tr>
                            <td><h6 style="color:white;">Adress</h6><input type="text" name="adress" id="ticket-form-name"   class="form-control" placeholder="Enter The adress" required></td>
                            <td><button type="submit" class="form-control" id="Sign_up_form_btn" >sign Up</button> </td>
                            <td><input type="hidden" name="hiddenField" value="Sign_up_form"></td>
                        </tr>
                    </table>
                </div>
            </form>
    </div>

 <script>

    
 </script>