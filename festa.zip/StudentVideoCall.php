<style>
       .Live_screen{
        width: 65vw;
        height: 95vh;
        
       }
       .Student_screen{
        width: 65vw;
        height: 60vh;
        
       }
       video{
        width: 65vw;
        height: 50vh;
        
       }
       #screenVideo{
        
       }
</style>

    <div class="Live_screen" >
        <div  class="Student_screen" >
            <video id="screenVideo" autoplay></video>
            <button id="startButton" class="   btn custom-btn d-lg-block d-none" >Start Screen Sharing</button>
             
        </div>
    </div>