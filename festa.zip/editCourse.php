 
        <div class="parentCourse_div" id="ParentCourse_div" >
                <div class="col-12 text-center">
                    <h3 class="mb-4" style="color: white;"> Edit Parent Course</h3>
                </div>
                <form id="edit_parent_course"   >
                    <table>
                        <tr>
                            <th>C_Name</th>
                            <th>Course_Id</th>
                            <th>Description</th>
                       
                             
                            
                        </tr>
                        <tr>
                            <td><input type="text" name="P_C_Name" style="color: white;" ></td>
                            <td><input type="text" name="P_Course_Id" style="color: white;"></td>
                            <td><input type="text" name="P_Description" style="color: white;"></td>
                        </tr>
                        <tr>
                            <th>Guide_name</th> 
                            <th>Guide_Email</th>
                            <th>Guide_Key</th>
                        </tr>
                        <tr>
                            <td><input type="text" name="P_Guide_name" style="color: white;"></td>
                            <td><input type="email" name="P_Guide_Email" style="color: white;"></td>
                            <td><input type="text" name="P_Guide_Key" style="color: white;"></td>
                        </tr>
                        <tr>
                            <th>Upload_img</th>
                        </tr>
                        <tr>
                            <td><input type="file" id="image" name="image" accept="image/*" style="color: white;"></td>
                            <td><input type="hidden" name="hiddenField" value="Edit_Parent_Form" style="color: white;"></td>
                        </tr>
                        <tr>
                            <td><button id="edit_parent_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
                        </tr>
                    </table>
                </form>
        </div>   
 
        <div class="subcourse_div" id="subCorse_div"> 
              <div class="col-12 text-center">
                <h3 class="mb-4" style="color: white;">Sub Courses</h3>
              </div>
              <form id="edit_Sub_course"  >
                  <table>
                      <tr>
                          <th>C_Name</th>
                          <th>Parnt_C_Name</th>
                          <th>Description</th>
                                                               
                      </tr>
                      <tr>
                          <td><input type="text" name="Sub_C_Name"></td>
                          <td><input type="text" name="Sub_Parnt_C_Name"></td>
                          <td><input type="text" name="Sub_Description"></td>
                          
                      </tr>
                      <tr>
                         <th>ImgName</th> 
                      </tr>
                      <tr> 
                           <td><input type="file" id="image2" name="image2" accept="image/*"></td>
                           <td><input type="hidden" name="hiddenField" value="Edit_Sub_Course_Form"></td>
                      </tr>
                      <tr>
                          <td><button id="edit_subcourse_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
                      </tr>
                  </table>
              </form>
              <div class="col-12 text-center">
                <h3 class="mb-4" style="color: white;"> Course Introduction</h3>
              </div>
              <form id="edit_course_info"  > <!-- Replace "anotherAction.php" with the appropriate action URL -->
                  <table>
                      <tr>
                          <th>C_name</th>
                          <th>Description</th>
                          <th>Learning_Outcomes</th> 
                                                           
                      </tr>
                      <tr>
                          <td><input type="text" name="descrip_C_name" ></td>
                          <td><input type="text" name="Intro_Description" ></td>
                          <td><input type="text" name="Learning_Outcomes"></td>
                          <td><input type="hidden" name="hiddenField" value="edit_Course_DescriptionForm"></td>
                      </tr>
                      <tr>
                          <th>Video_URL</th>  
                      </tr>
                      <tr>
                          <td><input type="text" name="Video_URL"></td>
                      </tr>
                      <tr>
                          <td><button id="edit_corse_info_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
                      </tr>
                  </table>
              </form>
        </div>    
  
    

    
  
   


 

<script>
 
</script>
        