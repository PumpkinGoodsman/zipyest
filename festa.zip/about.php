        <section class="about-section section-padding" id="section_2" style="background-image: none; background-color:  #101E14;">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-12 mb-4 mb-lg-0 d-flex align-items-center">
                        <div class="services-info">
                            <h2 class="text-white mb-4">About Cyber Nexus Tech</h2>

                            <p class="text-white">Festava Live is free CSS template provided by TemplateMo website. This
                                layout is built on Bootstrap v5.2.2 CSS library. You are free to use this template for
                                your commercial website.</p>

                            <h6 class="text-white mt-4">To Built Up Your Future</h6>

                            <p class="text-white">You are not allowed to redistribute the template ZIP file on any other
                                website without a permission.</p>

                            <h6 class="text-white mt-4">Our free courses</h6>

                            <p class="text-white">Please tell your friends about our website. Thank you.</p>
                        </div>
                    </div>

                    <div class="col-lg-6 col-12"  >
                        <div class="about-text-wrap">
                            <img src="images/pexels-alexander-suhorucov-6457579.jpg" class="about-image img-fluid">

                            <div class="about-text-info d-flex">
                                <div class="d-flex">
                                    <i class="about-text-icon bi-person"></i>
                                </div>


                                <div class="ms-4">
                                    <h3>a happy moment</h3>

                                    <p class="mb-0">your amazing Acadamic experience with us</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>