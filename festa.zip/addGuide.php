         
<div class="col-12 text-center">
    <h3 class="mb-4" style="color: white;"> add Guide</h3>
</div>
<form id="add_guide_myForm" >
    <table>
        <tr>
            <th>Guide_name</th>
            <th>Guide_Id</th>
            <th>Guide_email</th>
        </tr>
        <tr>
            <td><input type="text" name="Guide_name" style="color: white;" ></td>
            <td><input type="text" name="Guide_Id" style="color: white;"></td>
            <td><input type="email" name="Guide_email" style="color: white;"></td>
        </tr>
        <tr>
            <th>Guide_phone</th> 
            <th>GuideAdress</th>
            <th>Guide_Password</th>
        </tr>
        <tr>
            <td><input style="color: white;" type="tel" name="Guide_phone" pattern="^((\+92)|(0092))-{0,1}\d{3}-{0,1}\d{7}$" placeholder="Enter Pakistani phone number" required ></td>
            <td><input style="color: white;" type="text" name="GuideAdress"></td>
            <td><input style="color: white;" type="password" name="Guide_Password" placeholder="Enter password" required></td>
        </tr>
        <tr>
            <th>Guide_Course</th>
        </tr>
        <tr>
            <td><input type="text" name="Guide_Course" style="color: white;"></td>
            <td><input type="hidden" name="hiddenField" value="Add_Guide"></td>
        </tr>
        <tr>
            <td><button id="add_guide_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
        </tr>
    </table>
</form>

 