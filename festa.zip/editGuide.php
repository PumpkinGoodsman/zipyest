         
                <div class="col-12 text-center">
                    <h3 class="mb-4"> add Guide</h3>
                </div>
                <form id="edit_Guide_Form"   >
                    <table>
                        <tr>
                            <th>Guide_name</th>
                            <th>Guide_Id</th>
                            <th>Guide_email</th>


                             
                            
                        </tr>
                        <tr>
                            <td><input type="text" name="Guide_name" ></td>
                            <td><input type="text" name="Guide_Id"></td>
                            <td><input type="email" name="Guide_email"></td>

                             
                        </tr>
                        <tr>
                            <th>Guide_phone</th> 
                            <th>GuideAdress</th>
                            <th>Guide_Password</th>
                        </tr>
                        <tr>
                            <td><input type="tel" name="Guide_phone" pattern="^((\+92)|(0092))-{0,1}\d{3}-{0,1}\d{7}$" placeholder="Enter Pakistani phone number" required></td>
                            <td><input type="text" name="GuideAdress"></td>
                            <td><input type="password" name="Guide_Password" placeholder="Enter password" required></td>
                        </tr>
                        <tr>
                             <th>Guide_Course</th>
                        </tr>
                        <tr>
                            <td><input type="text" name="Guide_Course"></td>
                            <td><input type="hidden" name="hiddenField" value="edit_Guide"></td>
                        </tr>
                        <tr>
                            <td><button id="edit_Guide_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
                        </tr>
                    </table>
                </form>
      