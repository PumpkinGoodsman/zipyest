<style>
    #testDiv{
        width: 20vw;
        height: 20vh;
        border: 2px solid red;
    }
</style>


<div>

<button onclick="checkStudent('haji' , 'chanay')" >click</button>
</div>
<div id="testDiv" >

</div>

<script>
function checkStudent(studentName, courseName) {
    // Check if the data is valid (you need to define this condition)
       
        var formElement = [studentName, courseName];
        var formData = new FormData();

        // Assuming you want to send studentName and courseName as form data
        formData.append('studentName', studentName);
        formData.append('courseName', courseName);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'temp2.php'); // Change this to the actual PHP file that processes the form

        xhr.onload = function () {
            if (xhr.status === 200) {
                // Display the response in the resultDiv
                // var response = JSON.parse(xhr.responseText);
                document.getElementById('testDiv').innerHTML = xhr.responseText;
            } else {
                // Handle errors if any
                alert('An error occurred while processing the form.');
            }
        };

        xhr.onerror = function () {
            // Handle errors if any
            alert('An error occurred while processing the form.');
        };

        xhr.send(formData);
 
}
             
                
</script>
