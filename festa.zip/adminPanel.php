 <?php
include 'connection.php';
$user_on_page = "unknown";
$user_name ="unknown";
$admin_Id = "unknown";
$is_page_login= "unknown";
$user_on_page=  "unknown";


session_start();
if (isset($_SESSION["user_on_page"])) {
    header("Location: index.php");
  }
function exit_page(){
  header("Location: index.php");
} 
if(!isset($_SESSION["user_on_page"])){
  
}
function check_admin_login($connect, $admin_name, $admin_email, $admin_password) {
    // Use prepared statements to prevent SQL injection
    $connection = $connect;
    $sql = "SELECT Admin_Name, admin_Id, admin_Email FROM admin_info WHERE Admin_Name = ? AND admin_Email = ? AND admin_Password = ?";
    
    // Prepare the statement
    $stmt = $connection->prepare($sql);
    
    // Check for errors in prepared statement preparation
    if (!$stmt) {
        die("Error in SQL statement: " . $connection->error);
    }
    
    // Bind parameters and execute the query
    $stmt->bind_param("sss", $admin_name, $admin_email, $admin_password);
    $stmt->execute();
    
    // Check for errors in query execution
    if ($stmt->error) {
        die("Error executing SQL query: " . $stmt->error);
    }
    
    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Start a session
        session_start();

        while ($row = $result->fetch_assoc()) {
            $admin_name = $row['Admin_Name'];
            $admin_Id = $row['admin_Id'];
            $admin_email = $row['admin_Email'];
            $is_page_login = true;
            $user_on_page = "admin";
            
            $_SESSION["username"] = $admin_name;
            $_SESSION["admin_Id"] = $admin_Id;
            $_SESSION["is_page_login"] = $is_page_login;
            $_SESSION["user_on_page"] = $user_on_page;

            // Redirect to the adminDashboard.PHP page
            header("Location: adminDashboard.php");
            exit; // Make sure to exit to prevent further script execution
        }
    } else {
        // Handle invalid login (e.g., display an error message)
        echo "Invalid login credentials";
    }
}

if(isset($_POST['Guide_name'])){
    check_admin_login($connection, $_POST['Guide_name'], $_POST['Guide_email'], $_POST['Guide_password']);
}

 
 

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">

    <title>Festava Live - Bootstrap 5 CSS Template</title>

    <!-- CSS FILES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;400;700&display=swap" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/bootstrap-icons.css" rel="stylesheet">

    <link href="css/templatemo-festava-live.css" rel="stylesheet">

    <!--

TemplateMo 583 Festava Live

https://templatemo.com/tm-583-festava-live

-->
    <style>
        body{
            overflow-x: hidden;
            background-color: #F9F9F9;

        }
        .Login_forms{
            width: 25vw;
            height: 80vh;
            position: absolute;
            z-index: 8;
            top: 0%;
            left: 70%;
            top: 10%;
            opacity: 0.94;
            border-radius: 20px;
            
             
        }
        form{
          height: 50vh;
          background-color: transparent;
    
        }
        #teacher_form{
             
            
        }
        #form_table{
            display: flex;
        }
        .select_btn{
            background-color: transparent;
            border-radius: 7px;
            width: 6vw;

        }
        .target_btn_class{
            border: 1px solid #219c02;
            box-shadow: 0 0 8px #219c02; 
        }
        #student_form{
            
        }
        #signUp_form{
            width: 45vw;
            height: 80vh;
            position: absolute;
            z-index: 8;
            top: 0%;
            left: 30%;
            top: 20%;
            opacity: 0.94;
            border: 2px solid white;
            border-radius: 20px;
            background-color: white;
            
        }
        form{
          height: 50vh;
          background-color: transparent;
          
        }
        #testDiv{
            width: 20vw;
            height: 20vh;
            border: 2px solid red;
        }
        #container22 {
            position: relative;
            width: 200px;
            height: 200px;
            margin: auto;
            transform: rotate(45deg);
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
        }

        .test {
            width: 40vw;
            height: 40vh;
            position: relative;
            margin-top: 15%;
            left: 20%;
        }

        /* Glowing effect */
        .point {
            background-color: parrotgreen;
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(0, 255, 0, 0.7);
       
        }



    </style>
</head>

<body style="background-image: none; background-color: tranparent  ;" >

    <main >
          
        <div class="test">
            <canvas id="container22" width="200" height="200"></canvas>
        </div>
        <div class="Login_forms" id="Login_form" style="background-image: none; background-color:  #150E19; border: 0.5px solid #269524; filter: drop-shadow(2px 2px 4px #219c02);">
            <h3 class="text-center mb-4"  style="color:white;">Login</h3>
            <form class="custom-form ticket-form mb-5 mb-lg-0" id="admin_form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" style="background-image: none; background-color:  #150E19; " >
                <div class="ticket-form-body"  >
                    <table> 
                        <tr>
                            <td><h6 style="color:white;">Guide Name</h6><input type="text" name="Guide_name" id="ticket-form-name"   class="form-control" placeholder="Full name" required></td>
                        </tr>
                        <tr>
                            <td><h6 style="color:white;">Email</h6><input type="text" name="Guide_email" id="ticket-form-name"   class="form-control" placeholder="Full name" required></td>
                        </tr>
                        <tr>
                            <td><h6 style="color:white;">Password</h6><input type="text" name="Guide_password" id="ticket-form-name"   class="form-control" placeholder="Full name" required></td>
                        </tr>
                        <tr>
                            
                            <td><button type="submit" class="form-control" id="teacher_form_btn" >Login</button> </td>
                            <td><input type="hidden" name="hiddenField" value="teachers_login_form"></td>
                        </tr>
                    </table>
                </div>
            </form>
 
        </div>
 
    </main>



        <!--

T e m p l a t e M o

-->

    <!-- JAVASCRIPT FILES -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/click-scroll.js"></script>
    <script src="js/custom.js"></script>
    <script>
        var points = [],
        velocity2 = 5, // velocity squared
        canvas = document.getElementById('container22'),
        context = canvas.getContext('2d'),
        radius = 5,
        boundaryX = 200,
        boundaryY = 200,
        numberOfPoints = 30;

        init();

        function init() {
        // create points
        for (var i = 0; i < numberOfPoints; i++) {
            createPoint();
        }
        // create connections
        for (var i = 0, l = points.length; i < l; i++) {
            var point = points[i];
            if (i == 0) {
            points[i].buddy = points[points.length - 1];
            } else {
            points[i].buddy = points[i - 1];
            }
        }

        // animate
        animate();
        }

        function createPoint() {
        var point = {}, vx2, vy2;
        point.x = Math.random() * boundaryX;
        point.y = Math.random() * boundaryY;
        // random vx 
        point.vx = (Math.floor(Math.random()) * 2 - 1) * Math.random();
        vx2 = Math.pow(point.vx, 2);
        // vy^2 = velocity^2 - vx^2
        vy2 = velocity2 - vx2;
        point.vy = Math.sqrt(vy2) * (Math.random() * 2 - 1);
        points.push(point);
        }

        function resetVelocity(point, axis, dir) {
        var vx, vy;
        if (axis == 'x') {
            point.vx = dir * Math.random();
            vx2 = Math.pow(point.vx, 2);
            // vy^2 = velocity^2 - vx^2
            vy2 = velocity2 - vx2;
            point.vy = Math.sqrt(vy2) * (Math.random() * 2 - 1);
        } else {
            point.vy = dir * Math.random();
            vy2 = Math.pow(point.vy, 2);
            // vy^2 = velocity^2 - vx^2
            vx2 = velocity2 - vy2;
            point.vx = Math.sqrt(vx2) * (Math.random() * 2 - 1);
        }
        }

        function draw() {
        for (var i = 0, l = points.length; i < l; i++) {
            // circles
            var point = points[i];
            point.x += point.vx;
            point.y += point.vy;

            // Draw glowing points
            context.beginPath();
            context.arc(point.x, point.y, radius, 0, 2 * Math.PI, false);
            context.shadowBlur = 10;
            context.shadowColor = "rgba(0, 255, 0, 0.7)";
            context.fillStyle = 'parrotgreen';
            context.fill();

            // lines
            drawLine(point.x, point.y, point.buddy.x, point.buddy.y);

            // check for edge
            if (point.x < 0 + radius) {
            resetVelocity(point, 'x', 1);
            } else if (point.x > boundaryX - radius) {
            resetVelocity(point, 'x', -1);
            } else if (point.y < 0 + radius) {
            resetVelocity(point, 'y', 1);
            } else if (point.y > boundaryY - radius) {
            resetVelocity(point, 'y', -1);
            }
        }
        }

        function drawLine(x1, y1, x2, y2) {
        context.beginPath();
        context.moveTo(x1, y1);
        context.lineTo(x2, y2);
        context.strokeStyle = 'parrotgreen';
        context.stroke();
        }

        function animate() {
        context.clearRect(0, 0, 200, 200);
        draw();
        requestAnimationFrame(animate);
        }
//#101E14
</script>

</body>

</html>