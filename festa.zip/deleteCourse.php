 
 <div class="parentCourse_div" id="ParentCourse_div" >
                <div class="col-12 text-center">
                    <h3 class="mb-4" style="color: white;"> Parent Course</h3>
                </div>
                <form id="delete_parent_Course" >
                    <table>
                        <tr>
                            <th>C_Name</th>
                            <th>Course_Id</th>                                                        
                        </tr>
                        <tr>
                            <td><input type="text" name="P_C_Name" style="color: white;"></td>
                            <td><input type="text" name="P_Course_Id" style="color: white;"></td>
                            <td><input type="hidden" name="hiddenField" value="delete_parent_Course"></td>
                        </tr>
                        <tr>
                            <td><button id="delete_parent_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
                        </tr>
                    </table>
                </form>
         </div>   
 
        <div class="subcourse_div" id="subCorse_div"> 
              <div class="col-12 text-center">
                <h3 class="mb-4" style="color: white;">for Sub Courses </h3>
              </div>
              <form id="delete_Sub_course"  >
                  <table>
                      <tr>
                          <th>C_Name</th>           
                      </tr>
                      <tr>
                          <td><input type="text" name="Sub_C_Name" style="color: white;"></td>
                          <td><input type="hidden" name="hiddenField" value="delete_Sub_course"></td>
 
                      </tr>
                      <tr>
                          <td><button id="delete_subcourse_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
                      </tr>
                  </table>
              </form>
              <div class="col-12 text-center">
                <h3 class="mb-4" style="color: white;">Del Course Intro </h3>
              </div>
              <form id="Delete_info"  > <!-- Replace "anotherAction.php" with the appropriate action URL -->
                  <table>
                      <tr>
                          <th>C_name</th>
                                   
                      </tr>
                      <tr>
                          <td><input type="text" name="descrip_C_name" style="color: white;"></td> 
                          <td><input type="hidden" name="hiddenField" value="delete_Course_info"></td>
                      </tr>
                      <tr>
                          <td><button id="delete_corse_info_submitBtn" class="btn custom-btn d-lg-block d-none" style="margin-top: 3%;">Submit</button></td>
                      </tr>
                  </table>
              </form>
        </div>              
  
 
  
    

    
  
   


 

<script>
 
</script>
        