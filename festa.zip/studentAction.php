<?php
include 'connection.php'; 

$user_on_page = "unknown";
$user_name ="unknown";
$admin_Id = "unknown";
$is_page_login= "unknown";
$user_on_page=  "unknown";


session_start();
if (isset($_SESSION["user_on_page"])) {
  $user_name =  $_SESSION["username"] ;
  $admin_Id = $_SESSION["admin_Id"];
  $is_page_login= $_SESSION["is_page_login"];
  $user_on_page=  $_SESSION["user_on_page"];

  }
 
if(!isset($_SESSION["user_on_page"])){
   header("Location: index.php");
}

function check_course_id($connection, $student_name, $student_id, $course_name, $course_id ,$student_cnic ) {
    // Sanitize inputs to prevent SQL injection
    $student_name = $connection->real_escape_string($student_name);
    $student_id = $connection->real_escape_string($student_id);
    $course_name = $connection->real_escape_string($course_name);
    $course_id = $connection->real_escape_string($course_id);

    // SQL query to check if the course exists
    $sql = "SELECT C_Name, Course_Id FROM parent_courses WHERE C_Name = '$course_name' AND Course_Id = '$course_id'";
    $result = $connection->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
           echo "done";
           fetch_student_details($connection, $student_name, $student_id  , $student_cnic , $course_name );
        }
    } else {
        echo "Not done";
    }

}

//$is_valid_Cid =   check_course_id($connection, "haji", "443322", "Machine_learning", "machione443");
 

function fetch_student_details($connection, $student_name, $student_id  , $student_cnic , $course_name ) {
    // Sanitize inputs to prevent SQL injection
    $student_name = $connection->real_escape_string($student_name);
    $student_id = $connection->real_escape_string($student_id);

    // Corrected SQL query syntax
    $sql = "SELECT student_name, student_Id, student_email, student_phone FROM student_details WHERE student_name = '$student_name' AND student_Id = '$student_id'";
    $result = $connection->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $student_name = $row["student_name"];
            $student_Id = $row["student_Id"];
            $student_email = $row["student_email"];
            $student_phone = $row["student_phone"]; // Assuming "C_Name" is a column in the result set
            // Do something with $course_name if needed
           echo  $student_name  ;
           echo "<br>";
           echo   $student_Id  ;
           echo "<br>";
           echo  $student_email  ;
           echo "<br>";
           echo  $student_phone ;
           echo "<br>";
           register_student($connection, $course_name, $student_name, $student_id, $student_cnic, $student_email, $student_phone);
        }
    } else {
        echo "No results found.";
    }
}
 

function register_student($connection, $tablename, $student_name, $student_id, $student_CNIC, $student_gmail, $student_phone) {
    // Sanitize inputs to prevent SQL injection
    $tablename = $connection->real_escape_string($tablename);
    $student_name = $connection->real_escape_string($student_name);
    $student_id = $connection->real_escape_string($student_id);
    $student_CNIC = $connection->real_escape_string($student_CNIC);
    $student_gmail = $connection->real_escape_string($student_gmail);
    $student_phone = $connection->real_escape_string($student_phone);

    // Construct the table name using concatenation
    $table_name = $tablename . "_students";

    // SQL query to insert student details into the specified table
    $sql = "INSERT INTO $table_name (student_name, student_id, student_CNIC, student_gmail, student_phone) VALUES ('$student_name', '$student_id', '$student_CNIC', '$student_gmail', '$student_phone')";

    if ($connection->query($sql) === TRUE) {
        echo "Student registered successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}

 
function edit_Parent_Course($connect, $student_name, $student_id, $Student_phone, $Student_Adress, $Student_Password, $Student_email, $Student_img) {
    // File upload code
    $uploadedFile = $Student_img;
    $targetDir = "C:\\xampp\\htdocs\\festa\\images\\";
    $targetFile = $targetDir . basename($uploadedFile["name"]);
    $imgName = "images/" . $uploadedFile["name"];

    if(isset($uploadedFile) && $uploadedFile["error"] == 0) {
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $allowedFormats = array("jpg", "jpeg", "png");

        if (in_array($imageFileType, $allowedFormats)) {
            if (move_uploaded_file($uploadedFile["tmp_name"], $targetFile)) {
                echo "File uploaded successfully.";
            } else {
                echo "Error uploading file.";
                return;
            }
        } else {
            echo "Invalid file format. Only JPG, JPEG, and PNG files are allowed.";
            return;
        }
    } else {
        echo "No file uploaded.";
        return;
    }

    // SQL update code
    $update_sql = "UPDATE student_details SET student_name=?, student_Id=?, student_email=?, student_phone=?, student_Adress=?, student_Password=?, student_img=? WHERE student_name=? AND student_Id=?";
    
    $stmt = mysqli_prepare($connect, $update_sql);
    
    mysqli_stmt_bind_param($stmt, "sssssssss", $student_name, $student_id, $Student_email, $Student_phone, $Student_Adress, $Student_Password, $imgName, $student_name, $student_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "Record updated successfully!";
    } else {
        echo "Error updating record: " . mysqli_stmt_error($stmt);
    }
    
    mysqli_stmt_close($stmt);
    mysqli_close($connect);
}

// Example usage:
// $connect = mysqli_connect("hostname", "username", "password", "database_name");
// edit_Parent_Course($connect, $student_name, $student_id, $Student_phone, $Student_Adress, $Student_Password, $Student_email, $_FILES["image"]);
 


if (isset($_POST['hiddenField'])) {

    $rrrr = $_POST['hiddenField'];
    if($rrrr == "course_registeration"){
      check_course_id($connection, $user_name, $admin_Id, $_POST['Course_Name'], $_POST['Course_id'] ,$_POST['Student_CNIC'] );      
    }
    if($rrrr == "Edit_Student_profile"){

      edit_Parent_Course($connection, $user_name , $admin_Id, $_POST['Student_phone'], $_POST['Student_adress'], $_POST['Student_Password'], $_POST['student_email'], $_FILES["image"]);
      
    }
}
?>