
<?php 
include 'connection.php';


 
function print_faculty_events($connect) {

    $connection = $connect;

    $select_sql = "SELECT EventName, Topic, time, Hosted_By FROM faculty_webinar";

    $result = mysqli_query($connection, $select_sql);

    if ($result) {
        // Fetch and display all records
        while ($row = mysqli_fetch_assoc($result)) {
            $event_name = $row['EventName'];
            $event_topic = $row['Topic'];
            $event_time = $row['time'];
            $event_host = $row['Hosted_By'];
            echo '<td class="table-background-image-wrap  ">
                    <h3>' . $event_name . '</h3>
                    <p class="mb-2">' . $event_topic . '</p>
                    <p class="mb-2">' . $event_time . '</p>
                    <p class="mb-2">' . $event_host . '</p>
                    <div class="section-overlay">
                    </div>
                </td>';
        }

        mysqli_free_result($result);
    } else {
        echo "Error fetching records: " . mysqli_error($connection);
    }

     
}

function print_student_events($connect) {

    $connection = $connect;

    $select_sql2 = "SELECT EventNAme ,Topic  , Time, Hosted_By FROM students_webinar";

    $result = mysqli_query($connection, $select_sql2);

    if ($result) {
        // Fetch and display all records
        while ($row = mysqli_fetch_assoc($result)) {
            $event_name = $row['EventNAme'];
            $event_topic = $row['Topic'];
            $event_time = $row['Time'];
            $event_host = $row['Hosted_By'];
            echo ' 
            <td class="table-background-image-wrap">
                <h3>' . $event_name . '</h3>
                <p class="mb-2">' . $event_topic . '</p>
                <p class="mb-2">' . $event_time . '</p>
                <p class="mb-2">' . $event_host . '</p>
                <div class="section-overlay">
                </div>
            </td>
           ';
        }

        mysqli_free_result($result);
    } else {
        echo "Error fetching records: " . mysqli_error($connection);
    }

    
}

function print_upcoming_courses($connect) {

    $connection = $connect;

    $select_sql = "SELECT Course_name, Duration , launch_Date , Hosted_By FROM upcoming_courses";

    $result = mysqli_query($connection, $select_sql);

    if ($result) {
        $i = 0 ;
        // Fetch and display all records
        while ($row = mysqli_fetch_assoc($result)) {
            $i = $i+1;
            echo $i;
            if($i = 2){
                $Course_name = $row['Course_name'];
                $Duration = $row['Duration'];
                $launch_Date = $row['launch_Date'];
                $Hosted_By = $row['Hosted_By'];
                echo '<td class="table-background-image-wrap  ">
                        <h3>' . $Course_name . '</h3>
                        <p class="mb-2">' . $Duration . '</p>
                        <p class="mb-2">' . $launch_Date . '</p>
                        <p class="mb-2">' . $Hosted_By . '</p>
                        <div class="section-overlay">
                        </div>
                    </td>';
            }
            else{
                echo '<td class="table-background-image-wrap " style="background-color:#150E19" >
                            <h3>' . $Course_name . '</h3>
                            <p class="mb-2">' . $Duration . '</p>
                            <p class="mb-2">' . $launch_Date . '</p>
                            <p class="mb-2">' . $Hosted_By . '</p>
                            <div class="section-overlay">
                            </div>
                     </td>';
            }        
        }

        mysqli_free_result($result);
    } else {
        echo "Error fetching records: " . mysqli_error($connection);
    }

     
}






?>
      
      
      <section class="schedule-section section-padding" id="section_4"  style="background-image: none; background-color:  #101E14;">
            <div class="container">
                <div class="row">

                    <div class="col-12 text-center">
                        <h2 class="text-white mb-4">Event Schedule</h1>

                            <div class="table-responsive" >
                                <table class="schedule-table table table-dark" >
                                    <thead>
                                        <tr>
                                            <th scope="col"  style="background-color:#150E19; border:none;"> </th>

                                            <th scope="col" style="background-color:#150E19; border:none;"> </th>

                                            <th scope="col" style="background-color:#150E19; border:none;"> </th>

                                            <th scope="col" style="background-color:#150E19; border:none;"> </th>

                                        </tr>
                                    </thead>

                                    <tbody>
                                        <tr>
                                            <th scope="row"> Faculty Events</th>
                                           <?php
                                              print_faculty_events($connection);
                                           ?>
                                        </tr>
                                        <tr> 
                                           <th scope="row"> Guide Events</th>
                                           <?php
                                                print_student_events($connection);
                                           ?>
                                        </tr>
                                        <tr> 
                                            <th scope="row"> Upcoming Courses Events</th>
                                            <?php
                                               print_upcoming_courses($connection);
                                            ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </div>
            </div>
        </section>
